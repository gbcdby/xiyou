# #66 供给延迟 r1：候选比较

依据、固定candidate与唯一诊断身份见`design-r1.md`。本表均为设计判断，没有新运行、微测或效果保证。

| 候选 | 已有依据与能直接验证的变化 | 无法据此认领的收益 | 合同/选择 |
| --- | --- | --- | --- |
| 下一旧progress前串行刷新/读新头 | 可令record53前先发现已提交55，不再直接先开第二条旧进度。 | 仍须等record51返回才创建新读；此前第二动作、维护、checkpoint已排队；不等于节省record53整段59.3ms。 | 可在原串行义务内细化，风险最小；**只作对照，不作为此次主修正**。 |
| **单publisher内一个G + 一个W** | 新COMMIT在旧G未返回时即可创建新publisher工作/进入原lane；G2等待当时W收束。直接消除已证实的应用等待依赖，保持每条独立进度。 | 不能抢占旧RPC/SQL，也不能把commit55时刻当新读已执行。本人旧RPC ACK/proof到8150.194，且后续客户端51.6ms仍未知。 | **推荐主方案**；先窄修6943153121并独审/补模，再由隔离实现验证PG/adapter反例，通过原验收前不发布。 |
| 全量读发后一次清理所有进度，或无限高优先发送 | 可能延后进度写的竞争。 | 持续新head可令旧进度长期无机会；新绑定/失败和关闭收束更难说明。 | 不选；推荐方案用有限波次及一条进度机会约束公平，不无限追头。 |
| 批量标记<=head、合并多条COMMIT、弱锁/无锁进度 | 能直接删除事务数量或等待。 | 改变既定持久原子性及安装/授权围栏，不能以profile热区作为授权。 | 本轮排除，保每行FOR UPDATE/精确UPDATE/COMMIT。 |
| 删除全部receipt后RPC或只信当前sent回空ACK | 只有一份49→53确认为重复。 | 15份中其余14份多数前推视图，不能把它们都删掉；旧cursor真实授权与RPC返回合同仍在。 | 排除。不由一次重复推导新省略协议。 |
| packetCreate用完整结构比较代替中间canonical | 同轮created canonical为34.958ms/1738.7ms；expected与consume两次canonical、同步真实packet/once proof可保留。 | 比较/expected解析仍有成本；不是净节省34.958ms，更不保证移除114.1ms。 | 可独立做精确等价原型，未证明前不并入主修正或用其局部收益发布。 |
| sync前置少一份clone | 同轮sync前置build14.389 + capture10.214 =24.603ms；首E→seq62只采到4.740ms。 | 不是删掉两份state就省全窗144.191ms；隔离、缓存不可变和回滚边界未知，FOR SHARE不是投影纯函数证明。 | 当前不选；不能用共享可变引用换速度。 |
| 通用canonical编码分配优化 | 同轮canonical总209.109ms，跨验证、proof和合同调用；存在成本依据。 | 旧concat原型已因map分派/外部异常变化被反证；普通JSON样本一致不等于公开API等价。 | 未有合法且净收益足够的候选；保留旧反例，不重新采用已排除方案。 |

## packetCreate比较器的最低义务

当前适配器先`expected=canonicalize(value)`，同步packetCreate中JSON.parse实际ACK/EVENT，完整canonical比较，最后consume时再次canonical同一DTO。拟议优化只能替换中间编码，不能删三个阶段各自的完整证明职责。

可比较的私有域为本次已规范编码expected的解析树与本次实际JSON.parse的树，不是任意可变业务对象身份缓存。expected解析结果不得逃逸或跨发送复用；consume仍重核完整DTO以发现发送期间变动。对象自有key集合必须完全相同（顺序不作为语义），数组顺序/长度及所有叶值保留；数值`-0`按原canonical与0等价，不可直接改成Object.is区别；Unicode无归一化。

**只做deepEqual并遇到不等就return false不等价。** 原canonical在实际树里发现过深、不完整Unicode、不安全整数等会令整个发送窗口`failed=true`；假如同窗先有一包无效深子树、再有唯一好包，原实现必须拒绝proof。只数一个匹配好包而忽略无效坏包会误接受。新方案必须完整验证所有实际节点、键的深度与Unicode，保留同样failed语义和matches恰好1；无效子树不能因前面的字段不等而被跳过。

有限等价至少覆盖：真实两份20–21KB Batch、对象额外/缺失key、嵌套错值、数组乱序、-0、Unicode组合/代理对、超深键和值、unsafe/Infinity解析值、同窗坏包+好包、多匹配包、mutable DTO在send期间变化、伪proof/重复consume、错误handle/binding/kind、异常或async send、前后current变化。实际JSON.parse不会自行产生访问器/稀疏数组，不代表可用通用任意对象deepEqual替换公开canonical；公共canonical API与旧宿主反例完全保留。任何失败语义差异先排除候选，不以微秒收益覆盖。

## 结论范围

主方案要处理的是“已提交新前缀尚无机会进入原lane”的调度依赖；CPU候选只能减少其各自真实成本，客户端native→source仍需单独证据。任何一个局部正例都不足以证明原normal、late/five或官方CI通过。推荐的最短路径是先把必要窄delta及反例审清，验证确实发生新旧任务重叠且所有旧不变量保留，再按原体验门判断是否仍存在其他决定性等待；不把串行小改或局部微测包装成完成。
