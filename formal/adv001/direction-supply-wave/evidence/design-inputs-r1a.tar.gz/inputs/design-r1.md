# #66 供给延迟限定设计 r1：单 publisher 内分离发送与逐行进度

状态：**设计提案，待总控采纳及独立需求/标准/TLA审查；未实现，TLC/PG/浏览器均 NOT_RUN。** 不改原 finding OPEN，不以本稿或旧模型 PASS 声称方向体验通过。

读源基准：`aacbf377e3cb94cb2c9ec77c3609eac9e773b1e5`，tree `e760d4cfa13e99146177651db3029ba6794f6191`。本轮只读业务和冻结证据，未启动 browser、PG、profile、benchmark 或新 worker。

## 1. 推荐与必要合同修订

推荐**同一个 publisher 持有者、同一个当前 session 内，保留一个逐行进度任务，同时允许一个新的有界发送波次**。旧进度等待期间，新 COMMIT 只合并为需求并唤起新波次；新请求立即进入原 handle lane，不能再因全局发布函数正在 await 旧进度而尚无机会排队。每条进度仍独立取原 session FOR UPDATE，精确 UPDATE 单行并 COMMIT，不改变授权、锁模式、发送 proof 或 RPC 优先。

这是 [6943153121 已采纳合同](https://github.com/gbcdby/xiyou/issues/66#issuecomment-6943153121) 的**必要窄 delta**，不是现合同内随手挪 await。它所采纳的 [旧设计r1](https://github.com/gbcdby/xiyou/issues/66#issuecomment-6943056327) 明确“同record全部收束后进度、record逐条完成、不新增跨record并行”；新波次与旧进度存在重叠。逐条 COMMIT、记录顺序与同 handle lane 不变；改变的是较新前缀工作的启动时点和旧进度所依赖的收束集合。具体替换条款及模型义务见同目录 `model-delta-r1.md`。

**不选择仅在第二条旧进度前加一次新读作为主修正。** 那只能处理 record53 的第二道门，仍要等 record51 返回后才产生请求，不能切开已观测的应用等待依赖。也不选择批量进度、NOWAIT/SKIP LOCKED、更弱行锁、跳过 sync、缓存读权或提高 checkpoint 频率。候选比较见 `candidate-comparison-r1.md`。

## 2. 已有实证与可证收益的边界

主依据为一次带额外探针的冻结诊断 [E1]，**不是自然 CI**。seq55 在8119.411已发出COMMIT通知，旧队尾8146；publisher却在等待 record51 的进度8084.595–8153.708，随后先提交已覆盖 record53 的进度8157.421–8216.746。本人最终由RPC seq62在8260.1进入source，空窗114.1ms。两个进度锁读提交至首行分别58.940/50.786ms，包含数据库及调度等待，不能称纯锁时间。

新设计可以用受控交错直接验证：**旧进度尚未返回，更新的已提交前缀已经形成 publisher 工作并进入原 lane；旧进度完成后，也不能直接开启第二条旧进度而跳过已存在的发送波次。** 这是删掉一条应用调度依赖，不是预告节省58、69或114ms。

仍有三条硬限制：

- 本人旧cursor49 RPC的runtime.sync为8084.324–8135.771，ACK packet/proof窗口延至8150.194；新波次不能越过这个仍在途的同handle RPC。8119是可发起publisher需求的时刻，**不是新FOR SHARE必然入列时刻**。
- 原SQL记录中第二动作8099.094、维护8131.268、checkpoint8135.613都已先入列。新方案不抢占已在途progress，不改变数据库授锁顺序；FOR SHARE与FOR UPDATE仍互斥。[P1] 不能用新请求的较早创建直接推定读取完成或 packet 到达。
- 后一次空窗中native message8683已早于旧尾8695.1，source却到8734.6，native→source为51.6ms；浏览器decode/验证/调度细分未知，Node CPU不能替其归因。此处不由后端调度方案保证消除。

15份RPC里只有一份确认重复，另外14份多数实际推进本人视图。保留全部合法RPC入口、旧cursor的真实授权与sent上界，不能以这一份重复删除所有sync。

## 3. 状态归属与固定预算

协调器仍由 `GameRuntime.publishPending` 的原 `#publishing` 锁独占；外层 `committedPublisher` 的running、COMMIT标脏、200ms兜底及关闭等待仍有效。不新增第二个publisher实例、独立后台清理服务或跨session并发。

| 状态 | 唯一归属与限制 |
| --- | --- |
| 本轮记录集合 P | 沿原查询得到的有限、按session/through排序的Pending列表；当前session逐条尝试。新COMMIT可成为发送需求，但不无限追加本轮进度工作集。 |
| 最新需求 H / generation | 当前session仅一个合并头和一个代次。COMMIT通知、supply-ready及本轮初始已提交outbox查询可更新需求；不是授权、投影、sent或Published证明。 |
| 发送波次 W | 最多一个。开始时固定H和有限当前view候选；每个handle最多调用一次既有 `spatialSupply.publish`，一次波次不追逐不断增长的head。每组最多5个handle，超过5个按原方式分组、整组allSettled后再开下一组。 |
| 进度任务 G | 最多一个，目标为原顺序下一条可尝试记录；从duringPublish准备、取连接、BEGIN、锁读、复核到COMMIT/异常收束均算在此槽内。 |
| stop / firstError / owedProgress | 只控制是否还能启动新工作。不得把stopped、rejected或Promise已创建当成SQL/发送已结束。 |

H只决定是否值得安排一次原授权读。Batch实际边界、完整256页、当前frontier和读权仍由 `runtime.sync` 的本次事务决定；不能把H作为缓存授权或自己生成DTO。读取一页仍未到H时保留需求；有真实前进可再获下一波机会，但不能在同一波次内无限追头。RPC的原8页客户端边界不改。

同handle仍为1 active + 1 waiting RPC + 1合并publisher，RPC优先，绑定重试最多原有两次。预算5只计本publisher波次工作，不把独立RPC算成可绕开的工作，也不把房间5成员误当成活动handle上限。

## 4. 调度转换与公平选择

1. **进入新模式session。** 仅方向显式开启、全部当前活动view均v2且完整协商direction/timed-trail时进入。先接好当前session的轻量COMMIT/ready唤醒，再取得初始已提交头提示，合并两者避免接线窗口丢需求。监听器只标脏/唤醒，不执行SQL或发送。所有后续工作仍重新核当前对象与能力。
2. **开始W。** 有未尝试新需求、已有真实分页前进或新安装ready，且没有活动W时，固定H并重枚举当前view。每个工作调用原lane/授权/真实proof路径，返回covered、progressed、blocked、ignored或原错误；不能用H替代实际sent。原撤权/退休规则保留。
3. **开始G。** 只能在当时所有已启动W工作已经settle、且旧记录当前可信覆盖初检通过后开始；原全局安装pending初检保留。初检不授权COMMIT，G持原排他锁后仍须重新枚举所有当前view、核scope/fence/current/sent和全局eligible pending。
4. **G在途收到新COMMIT。** 若没有活动W，可开始一个新W；G仍占唯一进度槽，W仍受原lane与SQL行锁约束。允许重叠的是新任务排队、读取和发送生命周期，不允许冲突SQL同时持有同一session锁。
5. **W收束/G完成。** 下一条G不能在活动W未settle时启动。若fresh需求与旧可完成进度同时待选，最多先服务一个有限W；W收束后须给原顺序旧进度一次启动机会，再处理新波次。持续新head不能反复取消这份机会。G已在途时允许后续W逐波服务新需求，但永不同时存在两个W或两个G。
6. **无进展与轮次结束。** 同代次blocked/无前进不自行忙轮询；交回原新COMMIT/ready/200ms兜底。本轮P已尝试完后停止添加工作，等已开始W/G全部settle才离开当前session/释放publisher。新记录留给原下一轮，外层generation/pending重查仍须保留其唤醒。两槽均空且当次无工作时必须返回，不能挂住等未来事件。

这里的公平是有限调度预算：一个新波次不会无限追头，也不会让已具备进度条件的旧行永远失去本协调器的启动机会。**不承诺**无限RPC、无限换binding、永久SQL/网络等待下的最终成功；不改变原RPC优先或数据库公平性。

## 5. 失败、换绑定与关闭

**区分旧行完成依据与后来的新前缀工作。** G开始前，支持该旧行的发送工作已完成并有真实sent；之后W的失败不能伪称较新前缀已发送，也不能倒退其他peer已成功sent。它不把一个已经独立COMMIT的旧行改回Pending；尚未开始的进度停止，未完成行保留Pending重试。若G锁内发现当前view/pending变化，则仍必须不UPDATE该行。

任一需要上抛的错误或停止信号：立即禁止新W、新组、新peer、新G；已经开始、已排入lane、已提交SQL或正在真实发送的工作自然settle。记录首错误，但**不得Promise.race首个失败后直接释放publisher**；当前W全部工作与G必须一起allSettled，之后才上抛/返回。关闭不假装取消已开始SQL，也不提前释放连接、回滚已经COMMIT或丢掉成功peer的sent。

G的OUTCOME_UNKNOWN、SESSION_GONE、before/afterCommit hooks和连接释放沿原函数语义；提交响应丢失不能重标已Published行。重试先重读持久Pending集合，恢复数据仍以当前binding可信sent为起点。发送的实际packet一次性proof、同步窗口、当前socket/handle/binding完整DTO及发送前后围栏不改。

安装、新view、撤权、终态、关闭可能在W/G交错中发生。必须保留原锁内最终复核和真实adapter失败→retire→同步closing链；不能假设pending资格永远单调。当前新模式若变为混合能力，停止该优化路径的新工作，先收束两槽，再交原串行入口或原后续轮次处理剩余记录。不能凭进入时的能力快照继续新模式。defaultOFF、direction-only、legacy和原本混合模式不进入此协调器。

## 6. 最小代码落点

| 文件 | 限定变化 |
| --- | --- |
| `backend/runtime.mjs` | `publishPending` 的完整新模式session分支加入私有双槽协调器；沿用同一个#publishing所有者和有限原顺序P。`#publishOutboxProgress`的SQL/最终复核/COMMIT语义保持，原兼容分支保持。 |
| `backend/spatial-direction-runtime.mjs` | 原COMMIT/ready代次与200ms调度保留；仅在确有需要时传递轻量唤醒或停止信号。不得另起publisher或改checkpoint。 |
| `backend/spatial-supply.mjs`、`backend/socket-enqueue.mjs`、`backend/spatial-runtime.mjs` | 主方案默认不改；继续复用原lane、read、packet证明。性能比较不是顺带修改这些文件的授权。 |
| 现有publisher/parallel-supply及真实Socket/PG测试 | 增加下面具名交错，不改世界、输入、时长、观测阈值或原验收场景。 |
| `formal/adv001/` 下本次限定增量 | 由独立TLA worker按同目录模型义务建/改最小模型；旧结果保持原身份，不回填成新PASS。 |

协调器的监听器、唤醒Promise和两槽必须在一个生命周期内管理，finally拆监听并确认两槽收束后才释放#publishing。不得遗留稍后还能启动工作或拒绝未处理的Promise。

## 7. 直接验收与停止条件

主功能验收不能只看“publisher总耗时下降”：

1. **切开旧等待的正例与基线负控。** 两个真实handle已收到前缀53；控制record51进度的函数返回，例如其真实COMMIT之后的afterCommit门，使当前publisher仍在途；再产生真实COMMIT55。观察新publisher工作在record51函数返回前进入原lane。可用一个空闲handle证明实际新授权读已排队；本人handle有RPC时只允许publisher占等待槽，不宣称SQL已运行。基线串行实现应在这项判据失败。此例分离应用等待，不假设持有旧排他锁时另一世界写还能提交。
2. **实际数据库互斥。** 另用真实世界事务持有session写锁阻塞G；释放该世界事务并真实COMMIT55，观察W被唤起排队。再控制G已经获得原锁但尚未COMMIT的边界，W不得绕过该锁完成读取；G释放后新前缀真实packet到达，sent只凭真实proof推进。不得靠弱锁、无锁缓存或假proof换速度。
3. **第二条旧行与公平。** G51完成时W55仍在途，G53不得开始；W收束后按原顺序精确提交51/53。持续合并更多需求时，验证有限W结束会给旧行一次进度机会；>5真实handle首组未全部settle前第6个不得启动，也不能丢弃第6个。
4. **错误/停止反例。** A已真发送、B失败、C在途且G等待；再次publish应busy，关闭/上抛必须等C和G均settle。G实际COMMIT后丢响应，不能假回滚/重增attempts。新W失败不能推进其新head，其他成功sent不回退；旧行仅保留实际提交结果。
5. **安装/绑定/证明。** G锁前新pending、复核后真实发送失败/closing、换view、新读者、混合能力、无ACK/伪proof、RPC优先与旧cursor ceiling、关闭后的旧回调均须保留具名负控。检查后变化继续用真实adapter链，不只靠任意内存注入。

这些门通过后仍须当前原normal及适用late/five、速度/无idle/diagonal/DOWN原阈值与自然CI分别验证。**不能因排队正例或局部CPU降低就发布一个仍已知失败的体验候选。** 若新publisher已及时进lane而后续仍由旧RPC/SQL/客户端解码造成空窗，应保留该新证据并定位剩余边界，不能继续扩大并发、减时长、掩idle或把模型通过当体验通过。

## 证据索引

- **[E1]** `/workspace/scratch/af1da4413c53/xiyou-first-e-profile/.agent-output/first-e-diagnostic/investigation.md`，SHA256 `42a8471b4cf0901b416251f60fb6b68e7da9385f8f28e21018afc519987f928d`。本轮已全读，并核对`analysis.json`的progress/锁序/同步/supply字段、`timing.json`结构及`cpu-attribution.json`关键来源。
- 同轮唯一诊断原件`browser/result.json` SHA256 `11f3e938870d54ed6e4134e1902d4c12e5e6e71ce12760530caa5aef93460658`；1648项实际Motion复演零mismatch由总控提供并记录在E1。该诊断不能替代自然CI；独立JSON.parse钩子计数0。
- **[E2]** 旧编码反例报告：`/workspace/scratch/af1da4413c53/xiyou-encoding-equivalence/.agent-output/encoding-equivalence-investigation/investigation.md`；公开canonical拼接和iterator/RegExp反例未被本设计消除。
- **[P1]** PostgreSQL 18 [显式行锁说明](https://www.postgresql.org/docs/18/explicit-locking.html#LOCKING-ROWS)：FOR UPDATE与FOR SHARE互斥；同名BEGIN/COMMIT/响应等待不等于数据库内部授锁时刻。
