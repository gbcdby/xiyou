# #66 供给延迟 r1：合同 delta 与最小模型义务

状态：**提案，NOT_RUN**。本文件与`design-r1.md`配套；只定义独立TLA/PG需要核的新增状态，不修改旧模型或宣布通过。

## 1. 对6943153121及其采纳r1的最小修订文本

建议仅增加以下例外，其余原条款完整保留：

> 仅方向显式开启、v2且完整协商direction/timed-trail、当前session所有活动view均满足新模式时，单一publisher所有者内允许至多一个旧record进度任务与至多一个更新已提交前缀的发送波次并存；不新增跨session并发。发送波次每组最多5个真实handle，超过分组，原同handle lane容量及RPC优先不变。
>
> 每个进度任务开始前，当时已启动的发送波次必须全部settle，并对该旧行已有的当前可信覆盖做初检。该进度任务在途期间，新COMMIT可合并触发新的发送波次；这份新工作不成为旧行先前完成依据的替代品。下一条进度仍须等当时活动波次全部settle。进度在原session FOR UPDATE内重新核全局eligible pending、当前view/scope/fence与真实sent覆盖，按原记录顺序精确UPDATE单行并独立COMMIT。
>
> 新波次失败不能推进其未发送前缀，不能倒退成功peer的sent，也不能虚构已独立提交旧行的回滚。停止或错误后不再创建工作；全部已开始的发送、lane排队、SQL和进度任务必须settle，之后才释放唯一publisher。无进展仍交回原200ms兜底。公平选择只保证有限新波次之后旧可完成行有一次进度启动机会，不改变RPC优先或承诺数据库/网络时限。

这修改了“并发只在同一record内部、record之间不重叠”的范围，以及原PS-06的全局`SettledBeforeProgress`含义。**不能用旧44条TLC结果覆盖新重叠**。逐条持久边界、锁模式、实际packet一次性proof、current/pending终检、defaultOFF/混合回退、世界权威、r2轨迹/时间/paint和全部体验阈值不改。

## 2. 现有模型哪里不够

`formal/adv001/direction-supply-parallel/model/ParallelPublish.tla`只有一个record/phase，BeginProgress在AllSettled后进入locked；随后到CommitRow之间不能启动新peer任务。其`SettledBeforeProgress`要求整个locked/checked/updated期间全员已settle。新设计允许这期间另一个发送波次处于waiting/reading/candidate，故该不变量不能原样保留并称源码对应。

旧`Read`还把through设为当前record。实际sync早已可读到较新完整前缀，新方案把这种数据发送从进度record的生命周期中明确分出；增量模型必须区分**待提交的进度行R、需求提示H、同一次授权读的rowHead、实际through、真实sent/proof**。它们不能合并为一个“head”。

## 3. 最小状态与动作

建议极小规模：1个session/1个publisher、2个peer、2条本轮进度记录、1次较新提交头（可用head1..3）、预算1/2两种配置、每handle原lane的必要RPC占用抽象。真实5槽/第6handle另由PG测试，不必把模型扩到6peer。

| 状态/动作 | 必须显式区分 |
| --- | --- |
| demandHead/generation | 仅已提交需求提示；新提交可发生在progress请求等待期间。 |
| wave jobs | selected/queued/waiting-read/reading/candidate/sent-or-failed/settled；波次固定候选与H，一peer一页机会，后续页另波。 |
| progress job | none/admitted/waiting-lock/locked/checked/updated/committed-or-failed/settled；目标R固定，仅一个。 |
| priorWaveSettled / admission certificate | 进度开始时旧覆盖依据已收束；不冒充后续current/pending恒定。 |
| current/persistent binding、pending、closing | 保留旧安装与发送前后围栏；失败/关闭和检查后变化可交错。 |
| owedProgress | 一有限波次完成后旧可完成行有下一进度机会；不能通过无限更换H重启波次。 |
| stop/error/owner | 止新任务与全started收束分离；错误不直接清空任务槽。 |

QueueProgress与AcquireProgressLock分开；QueueRead与AcquireRead分开。允许新波次在旧progress未返回时进入原lane，并不允许FOR SHARE和FOR UPDATE在同一行同时持有。RPC占用时publisher只能占原等待槽，不能把“已创建工作”建模成“已获得行锁”。Check/UPDATE/COMMIT继续拆开，保留新pending或新view插入的负控。

## 4. 必须启用的性质与反例

| 义务 | 正性质及对应负控 |
| --- | --- |
| 唯一所有者与预算 | `SinglePublisher`、`OneProgress`、`OneWave`、`PeerBudget`；负控：两个G、两个波次或第Budget+1个peer同时开始。 |
| 正确收束范围 | `ProgressAdmissionAfterPriorWaveSettled`、`NoLeakedTasksOnRelease`；负控：旧波次尚未settle就启动G，或新W/G仍在途即释放/关闭完成。 |
| 精确持久进度 | `ExactRowCommit`、原顺序尝试、未完成/未知结果不能假Published；负控：按<=head批标、COMMIT前宣布完成、失败当成功。 |
| 当前覆盖与安装 | `PendingPreventsPublish`、`CurrentViewsCovered`；负控：只看启动时view集合、忽略检查后eligible pending/新读者、复制旧证书到新行。 |
| 授权与发送 | 固定rowHead、真实proof、binding/closing围栏、旧RPC sent ceiling；负控：把H当rowHead、用构造成功补sent、换binding仍发、绕过RPC或旧cursor越界。 |
| 新旧失败分离 | 新波次失败不提高新sent，已成功peer不回退；已实际提交旧行不被假回滚，尚未开始进度不因失败自动成功；负控：新失败伪推进、撤销旧COMMIT、成功peer重复发送凑全员。 |
| 有界公平选择 | 固定波次不追无限新head；eligible旧行在一个收束波次后保有进度机会；负控：不断更新H并取消进度机会、同代次blocked忙重试。 |

必须保留可达见证：

1. G1仍在waiting/locked/返回未完成，新的Commit3发生，W3已进入原lane；随后仍只有一个G、同session锁互斥。
2. RPC正占本人lane，W只能等待；另一空闲peer可独立排读。不能把这条见证误称本人已读取成功。
3. G1已COMMIT但W3仍在途：G2尚不能开始，publisher也不能释放；W3收束后G2再按原行独立提交。
4. 新W发送失败、旧G实际已提交；旧结果保留，新前缀不伪推进，所有任务收束后退出。
5. 换binding/pending/关闭在新旧任务之间交错，旧proof不能授权新binding；同一成功peer的sent不会因另一peer失败倒退。
6. 连续两次新需求被合并，但一个有限W之后仍可启动旧G；第6真实handle的分组义务由PG对应补证。

新增公平性若只做有界安全/见证，应如实说明未查liveness；若检查最终进展，必须显式声明SQL、原lane/RPC及网络最终settle的公平假设。不能以人为Done掩盖环境停滞，也不能把TLC步数翻译成毫秒。

## 5. PG/adapter补证与停止边界

原模型已知未完整覆盖eligible pending的非单调性。新重叠使新发送失败可发生在旧G复核/UPDATE/COMMIT之间，须重跑真实生产adapter的无ACK/失败→retire→同步closing交错，检查旧安装候选是否会错误复活；不能仅引用旧T12通过。

两条旧记录逐条进度、第一COMMIT成功第二失败、COMMIT已成功但丢回应、停止时新W和旧G同时在途、5+1真实handle、mixed能力切入、旧RPC回包与新push次序，均须真实PG/Socket证据。安装写与当前view安装仍走原session锁边界；若新增任何无锁改变该资格的路径，应返回设计，不作隐含安全假设。

本模型不证明自然normal延迟、数据库授锁调度、Node/浏览器CPU、native→source的51.6ms、任意peer/record规模、多实例或Crash。源码映射须明确新coordinator所有await/Promise/监听器的关闭责任；旧模型与新模型分开报告，不声称完整refinement。
