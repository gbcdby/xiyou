# #66 供给并行增量模型独立审查

## 结论与身份

**需求轴：PASS_WITHIN_SCOPE。标准轴：PASS_WITHIN_SCOPE。没有发现本次固定有限模型及其证据包内的 blocking finding。** 这是针对设计安全义务和正式记录的独立审查，不是业务实现、真实 PostgreSQL、Socket.IO、完整供给协议组合或动态体验验收通过。

| 项目 | 固定身份 / 状态 |
| --- | --- |
| 审查者 | `/root/inspect_local_state`，独立于设计、模型与实现作者；使用 `worker-review`，参考 `worker-tla` 的审查与执行要求 |
| 模型候选 | `0a3f95686a90b1d1aabf3630b2f845a9c7fbd621` |
| 模型 tree | `a8b401563c8b2ec7b1cba6ecc2c6947656157e01` |
| 业务 / 差异基准 | `7b0d3846fad50b2c73598cdda2ddd350b7d83cb6` / tree `0648491f24960557cdf303b94a77b392e84ce1bc` |
| 设计稿 SHA256 | `cd899058342ac9e5d571db675255946ac27eb00b46f5f2418a7e706d15285fbe` |
| 候选范围 | 仅新增 `formal/adv001/direction-supply-parallel/` 下 55 文件，5,423 行；旧 `direction-supply` 的 59 条记录无差异 |
| 原始归档 | `evidence/r1-records.tar.gz`，342,275 bytes |
| 归档 SHA256 | `dd032b85dd41c1e3d189e259846d3ad334c0b01e84837db50a1c7ea664dbb1ab` |
| 模型安全检查 | 9 个正配置 `PASS_WITHIN_SCOPE`；21 个负控和 14 个见证保留原始 `COUNTEREXAMPLE` |
| 模型独立审查 | 本报告 `REVIEWED`；不修改作者原始结果中的 `independent_model_review` 或 runner 状态 |
| 源码对应 | **PARTIAL / 待实现映射核验**。读取了固定基准及交接义务；基准尚未实现优化，原始 runner `implementation_status=NOT_ASSESSED` 保持有效 |
| 活性 / 死锁 / 产品运行 | 活性 `NOT_CHECKED`；所有配置显式关闭死锁检查；本任务未运行应用、PG 或浏览器测试 |

检查结束时模型工作树仍为上述 HEAD/tree，`git status --short` 为空，固定差异 `git diff --check` 通过。没有修改模型、配置、正式证据、业务代码或外部记录。

## 审查依据与证据继承

完整阅读了两个 `.tla` 模块、44 个配置的启用性质与常量、两个 manifest、两个 expectations、`check.py`、README、HANDOFF 和汇总结果，并按逐项原始归档交叉核验。审查目标是已采纳窄设计 r1 中的共享读、有限跨 handle 工作、全部收束、最终完成切点与逐行持久进度。

源调用链的部分分析沿用本审查者此前对固定 `7b0d384` 的标准审查和同一设计 SHA 的窄设计审查；本次重新核对 HANDOFF 六个源码 blob，均与该基准一致。继承仅用于判断模型假设对应哪些既有职责与未封闭边界，不将旧代码结论迁移为新优化实现通过。原 59 条供给记录没有重新运行，也没有宣称它们覆盖新增外层 fan-out。

本次机器核验摘要保存于同目录 `model-evidence-audit.json`，SHA256：`eec6757123116d0743e4bdbc46f9b0e279a1017860e7bc05855da0cc3a52421b`。审计脚本 `model-evidence-audit.py` 只读取固定候选和归档。审计没有发现差异项。

## 需求轴：已覆盖的有限义务

| 义务 | 模型与实际核对 | 结论 |
| --- | --- | --- |
| 合格共享读与相关排他写互斥 | `SharedRead` 分开 Acquire、Authorize、Build、Finish、Return；共享/普通排他模式、world/control 写和绑定变化都可交错。`LockExclusion`、`EligibleSharedOnly`、`AuthorizedBinding` 有精确错误变体。 | 有限范围内覆盖；真实 SQL 锁模式与所有生产写入口仍需实现/PG 对应 |
| 固定授权头与旧 cursor 上界 | `FixedAuthorizedHead` 检查历史返回值与读取时 row head；`Return` 不被合并进 COMMIT，允许其间世界写。`OldCursorCeiling` 有旧 cursor 配置与负控。实际读后写见证包含 Acquire→Authorize→Build→Finish→Return→BeginWrite→CommitWrite。 | 覆盖该两 handle、一次写的有限模型 |
| 有界跨 handle 工作 | 两 peer、Budget=1 可等待并继续，错误变体允许第二项启动并违反 `PeerBudget`；Budget=2 的见证真实到达两个共享读同时持锁。 | 检查抽象容量规则；不证明实际 5 个槽位或第 6 个 handle |
| 成功、失败与关闭的收束 | Start/Read/Send/Discard/Settle 独立；`SettledBeforeProgress` 与 `NoLeakedTasks` 有提前进度、失败早退、关闭早退负控。读失败和发送失败分别有非空见证，并保留其他 peer 已发送前缀。 | 检查安全收束边界；不证明 SQL/网络最终返回或公平性 |
| 完成切点 | BeginProgress、CheckProgress、UpdateRow、CommitRow 分开；最终覆盖枚举当前 live views，而非只检查最初 selected。模型允许无锁 Close。pending 与晚加入负控在检查后、提交前引入变化并确实报错。 | 在声明的 pending/安装互斥假设内成立；实际非单调资格映射未由该模型封闭 |
| 逐行进度与失败保留 | 每次 `txRows={record}`，`commitRows` 记录实际目标与行集合；批量错误变体违反 `ExactRowCommit`。失败/blocked 不准发布，已有发送前缀不回退。 | 两行、单次尝试范围内覆盖；COMMIT 响应未知与重试/Crash 恢复不在范围 |
| 可信发送与绑定隔离 | `deliveries` 保存发送当时的 binding/current/durable/closing/pending/live；`sent` 与 `proof` 分开，伪 proof、旧绑定、关闭发送均被精确负控捕获。 | 传输 proof 是被明确声明的抽象接口；没有证明真实 Socket 库行为 |

`SharedRead` 和 `ParallelPublish` 是两个独立有限模型。`positive-combined` 只组合后者内部的新加入、安装、失败与关闭，不是两模型、更不是整个客户端/服务端系统的 refinement 证明。README/HANDOFF 对此表述准确。`ParallelPublish.FixedReadHead` 虽有定义，但不在发布组启用性质中，本报告不将它计入已验证集合；固定授权头的正式启用检查来自 `SharedRead.FixedAuthorizedHead`。

## 标准轴：没有发现 guard 或证书自证

1. **提交证书保留了真实检验点。** `CommitRow` 仅要求正确事务阶段与 progress writer；它没有以 `AllCovered`、pending 为空或证书真假作为提交 guard。证书在提交动作中从当时的 `AllSettled`、实际 `pending`、实际当前 views 的覆盖和失败集合计算，随后由不变量检查历史提交。这不是直接把证书写成 TRUE。`UpdateRow` 的实际行集合也独立记录，故批量更新错误可以被观察。
2. **最终复核与提交没有被折叠。** `CheckProgress → UpdateRow → CommitRow` 存在可交错间隙。`negative-pending-after-check` 的归档轨迹在复核后、UPDATE 后执行 `UnlockedPending`，随后 CommitRow 违反 `PendingPreventsPublish`；`negative-join-after-check` 在复核后加入新 view，提交时违反 `CurrentViewsCovered`。这两条反例说明模型没有用一张检查时证书掩盖提交时变动。
3. **协议等待条件与待证性质分开判断。** BeginProgress 的 AllSettled、FinishPublisher 的无活动任务条件，是设计要求的等待/释放规则；各自有绕过该规则的错误动作与非空反例。不能仅因正确协议 guard 包含安全条件就称其自证；本次检查了这些条件确实对应拟议协议，并存在独立可观察的错误行为。
4. **授权、发送与安装有可观察错误路径。** 绑定、row head、真实发送 proof、installed/sent 与实际发送记录分别保留。负控不是只使计数器变化，而是放开共享资格、使用 live head、忽略旧 cursor 上界、伪造 proof、错误 binding/closing 发送等与需求相关的变体。
5. **没有隐藏裁剪或活性包装。** 启用的配置没有 `CONSTRAINT`、`ACTION_CONSTRAINT`、symmetry/VIEW 等状态裁剪，也没有仿真、随机搜索、DFID 或公平性性质。两个 Next 均采用有限输入的安全模型。允许等待和输入耗尽，故关闭死锁检查的理由与结论一致，不能从安全 PASS 推导 eventually / 延迟保证。

## 44 份正式记录核验与独立复跑

逐项核对了 46 个模型/配置文件的当前内容、汇总 SHA256、归档共同快照、每次原始 `inputs.files` 和字节数；44 份运行 manifest 与当前 manifest 完全相同。归档 expectations 与当前 expectations 一致，每个 profile 的配置、常量、启用不变量、时序性质、deadlock 开关、预期状态、目标、distinct 下限和实际结果相符。9 个正配置下限为 50，35 个负控/见证下限为 2。README 如实披露最初两个语义探针，未把探针当作这 44 份正式证据。

每份 result/manifest/messages/log 的归档路径与 SHA256 均匹配，没有缺项、重复路径或不安全归档路径。原始 status、reason、完成状态、统计、TLC exit、起止时间和汇总逐项一致。所有正式执行均为 BFS、1 worker、768 MiB heap、180 秒预算；没有超时、中断或警告。原始负控/见证的 wrapper runner exit 为 2、TLC exit 为 12，未被改写为正检查成功。

| 正配置 | distinct | 剩余队列 |
| --- | ---: | ---: |
| positive-shared | 412 | 0 |
| positive-mixed | 393 | 0 |
| positive-old-cursor | 412 | 0 |
| positive-publish | 82 | 0 |
| positive-install | 1,858 | 0 |
| positive-join | 349 | 0 |
| positive-failure | 5,453 | 0 |
| positive-budget | 50 | 0 |
| positive-combined | 70,181 | 0 |

21 个负控均命中各自唯一目标，反例至少含 2 个状态；14 个见证均命中预声明否定性质，轨迹至少含 3 个状态。见证仅作为独立配置启用的否定性质，未成为搜索约束。实际核了代表性动作轨迹：预算越界、失败与关闭早退、伪 proof、两个读者同时持锁、关闭后收束、分别读/发送失败保留，以及两种检查后变动。

固定工具为 TLC 2.19 / v1.7.4；本地 jar 实际 SHA256 `936a262061c914694dfd669a543be24573c45d5aa0ff20a8b96b23d01e050e88`，与 44 份记录一致；归档 runner SHA256 `ca5811a8cae5d31961185b0ba53868f3ea885a1ee614150d873d61044ff18f5a` 也一致。未重新执行全部 44 项；独立使用固定候选的 `check.py` 有界复跑了以下两项，原始输出位于同目录 `model-review-rerun/`：

| 独立复跑 | 结果 | 实际证据 |
| --- | --- | --- |
| publish / positive-budget | `PASS_WITHIN_SCOPE` | generated 52 / distinct 50 / queue 0；TLC rc 0 |
| publish / negative-pending-after-check | `COUNTEREXAMPLE`，命中 `PendingPreventsPublish` | generated 72 / distinct 45 / queue 1；17 状态反例；TLC rc 12 |

复跑统计与作者归档一致，原始 `implementation_status` 仍是 `NOT_ASSESSED`。这两个复跑证明复现路径和重点反例可运行，不扩展有限检查范围。

## pending 非单调资格与真实 adapter 的边界

模型 `pending` 是“候选存在就阻塞”的接口假设，实际 `pendingViewInstallation/canInstallConnectionView` 则还依赖 current 对象、sent 水位、scope/fence、terminal generation、closing 和 handles。**更保守地阻塞模型动作，并不自动构成对真实程序所有执行的安全 over-approximation。** 因此，本报告只接受作者对有限设计接口的结论，不以该抽象消除真实谓词非单调的映射义务。

已核基准生产调用链给出合理的静态收束依据：`sendChecked` 失败、runtime 撤权/发布错误等 notify retire 路径触发 `retireView(view,true)`；server 的 `view-revoked` 监听同步调用当前 socket 的 `disconnect(true)`，disconnect 回调调用 `runtime.disconnect`，后者在首个 await 前将 handle 标记 closing。非 notify 的安装 retire/set 处于原 session 锁内；disconnect 收尾已有 closing；runtime close 受服务 tracked 工作收束保护；legacy sync 的相关 retire 也在原 session 锁内。

本次没有确认一个生产可达的“非 closing、无相应 session 排他边界的 retire，使先前不 eligible 的候选在最终 check 后重新 eligible”的反例。但以上静态调用链**不是已经执行的 Socket.IO/PG 验证**。实现候选仍须验证实际回调顺序、完整 pending/current 写入者集合、旧 RPC 读完后失败/retire、最终 check 到 UPDATE/COMMIT 的 await 间隙。若真实程序存在模型允许集之外的增长路径，须修订原子边界或补模；不能用本报告 PASS 将其略过。

## 尚需证据与停止点

这些是正式交接中已经声明的实现/集成义务，不是本次固定模型包的新增 blocking finding：

- 新实现固定候选的真实 PG 共享读重叠、相关 world/control/revoke/install 写互斥、每次授权及固定 row head；普通/defaultOFF/direction-only/legacy/混合能力选择路径不变。
- 至少 6 个真实 handle、预算 5 的分组调度与第 6 个读者处理；成功 A、失败 B、尚未 settle 的 C 同时存在时，不提前释放 publisher 或关闭。
- 真实 adapter 的同步 closing 映射、全局 pending/当前 view 的最终切点、旧 RPC 失败及新安装/新订阅的受控交错。
- 每行精确 UPDATE/独立 COMMIT、SESSION_GONE、rollback、COMMIT unknown、hooks/control priority 和 client release；这些实际 SQL/错误路径没有被本包执行。
- 旧协议、cache、客户端分页/应用的组合复核，以及完整候选原 normal→late→five/P05 与 CI。模型不证明 200/400ms、网络到达、Canvas、速度、累计路径或 diagonal 体验。

本次审查已完成，固定结论可供总控继续实现和后续增量审查。需要返审的触发是修改模型/配置/正式证据、实现改变上述假设、或真实 PG/adapter 暴露新的可达交错；不等待业务新候选完成才交付本报告。
