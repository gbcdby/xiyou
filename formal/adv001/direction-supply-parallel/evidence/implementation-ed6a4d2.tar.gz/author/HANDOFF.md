# #66 供给性能窄实现：作者交接

## 冻结候选

- 分支：`auto/ch01-supply-20261117`。
- 基线：`7b0d3846fad50b2c73598cdda2ddd350b7d83cb6`。
- 生产实现及首两项测试：`cb822f80ef2a755371bdd6e464dcc6aa6a169cde`。
- 完整候选：`ed6a4d2fdeea9fa47159c2fee3590f94431624b1`；tree `d5a24d66f0770cdbc15859d4be9a02bd7163499e`。
- 后一提交只有测试增量，生产三个文件与总控已执行原 normal 的 cb822f8 完全相同。工作区干净，`git diff --check` 通过。
- 本地提交已完成；本 worker 未远端推送、改 Issue/PR、合并或发布。

## 实现及保留义务

新完整能力模式的 spatial-sync 使用 FOR SHARE，仍保留非 readOnly 的原完整授权事务、buildTransaction、prefix capture、同锁分页/head/high-water/trail 和 COMMIT。混合、缺 timed-trail、defaultOFF、legacy 不进入新发布分支。

同一 outbox record 先冻结有限候选，最多五个不同实际 handle 一组；六个及以上分组继续。相同 handle 的原 lane 不变。每组 Promise.allSettled 后才处理错误，成功者的真实 sent 保留，失败轮不能提前释放 single publisher。

每条进度保持独立 FOR UPDATE 与精确 UPDATE/COMMIT。仅取 session_id，不构造或捕获整世界。锁后重新枚举全局 eligible pending、当前活动 view、scope/current/完整能力和每个读者真实 sent 覆盖。保留控制优先入口、hooks、SESSION_GONE、提交结果未知和连接释放。

关闭标志只阻止启动新 peer 组、record 和进度；已开始的 peer 工作按原逐页循环自然 settle。没有新增逐页取消语义，也没有改 checkpoint、频率或 200ms 兜底。

## 实测

| 检查 | 结果 | 证据 |
| --- | --- | --- |
| 基线 7b：首两个真实 PG 反例 | 2 项 RED：不同 handle 不能同时读；第六 handle 测试首组仍只启动一个 | `red-shared-fanout.log` |
| cb 首两个反例 | 2/2 PASS | `green-shared-fanout.log` |
| 完整新增行为测试 | 12/12 PASS，28.27 秒 | `pg-behavior-final.log` |
| 既有针对性回归 | 80/80 PASS，45.53 秒 | `regression.log` |
| 总控固定 cb822f8 原 normal | **FAIL**：assertPresentationEvidence 没有观察到真实可见静止 paint 建立资格 | 总控原 `browser-normal/result.json`，SHA256 `60029109090423acfec5a23f8da203d50966868d04d91023b20071aa868ebec2` |
| late / five | NOT_RUN；normal 已失败，未绕过顺序 | 无通过声明 |

完整命令、候选与日志摘要在 `author-evidence.json`。既有回归覆盖 cold recovery、control priority、prefix state cache、supply PG/unit、sync frontier、commit order、terminal fences/views、direction publisher/direction。

新增 12 项覆盖：共享读重叠且写排斥；写先持锁时读等待并观察提交后的头；原旧 binding 拒绝；真实六 handle 容量五；成功 peer+失败 peer+blocked peer 全收束；duringPublish 新 pending 的锁后复核；逐行独立提交及第二行回滚；真实 COMMIT 已完成但回应丢失的 OUTCOME_UNKNOWN；合法 session 删除；冷暖缓存 DTO/轨迹相等、无世界写且命中后重核撤权；关闭后的工作收束；mixed 串行；实际生产 adapter 的无 ACK 退休交错。

六 handle 由两名真实成员和同一成员四条 heldElsewhere 只读连接组成，均经过真实 Socket 身份握手、PG 订阅/授权及真实发送证明，不是假造第六个成员或 stub 同步器。调度门仅控制执行交错。

冷缓存检查使用同一真实 PG 的新 AuthorityRuntime 命名空间与真实只读 handle；不是一次真实服务器宕机测试。原 p05-cold-recovery 另以真实冷重启覆盖双人 ACK 20 秒门槛，包含在 80 项回归内；不替代总控的整章 P05 浏览器。

## 非单调 pending 的实际 adapter 映射

真实 createAuthorityServer + PG + 两个真实 Socket。第一订阅 COMMIT 后暂停安装；较新订阅已安装并真实 ACK，以更高 current 水位令旧候选不 eligible。所有当前读者覆盖后，duringPublish 安排客户端真实不带 ACK 的 sync，SQL 读完成后停在发送前；逐行进度 check/UPDATE 后、COMMIT 前放行。

该实际发送因无入队证明走 sendChecked → retire(true) → 生产 socket.disconnect → runtime.disconnect，在首个 await 前 closing=true。旧候选没有因 current 退休重新 eligible，最终无法安装；该记录按原完成切点提交。未直接调用 retire(false)，未伪造 ACK/proof，未新增门闩。原件 `pg-adapter.log`；完整 12 项中也再次通过。

第一次 adapter 调度把在途 RPC 放在 peer 工作前，因此被原 same-handle lane 正确阻挡，实验没有形成目标交错；已中止该测试进程并保留 `pg-behavior-held-lane.log`，不算 PASS。最终测试把实际 RPC 安排在 duringPublish 切点，没有修改业务行为。另一个早期反向锁测试误选同 handle 安装 pending，先被正常拒绝；已改为普通持锁写来检验真实 PG 排斥，旧 binding 拒绝另作断言。

## 同次 normal 初始化证据补查

应 motion 作者要求，复制总控正常关闭后的 PG 数据到本任务目录，仅对独立副本执行 BEGIN READ ONLY 导出；原目录未重新启动或修改。精简导出与原 result 哈希在 `cb822-normal-clock-events.json`。

- seq 8：spatial.started，Running。
- seq 32/35：主玩家 epoch 2 与新视图；最近 clock 仍 paused=true/scene0。
- seq 36：第二玩家 HumanControlled epoch 2；同事务 seq 39 将 paused=false，scene0。
- seq 41：scene119，paused=false；seq 42：scene235，paused=false。

服务端解除暂停切点是 seq39。motion 作者核对的客户端首次跨界为 seq41（source/motion 已带 0→119 hold），当时 owner seal 仍 false；seq42 后首次出现 eligible paint。PG 导出不能独立证明前端 props 更新时序，交 motion 作者继续验证，不把 seq42 称为首次服务端解除暂停。

## 限制

作者代码与行为检查完成，不代独立需求/标准审查。新增 TLC 及其限定映射由 supply_tla 独占处理，本 worker 未写 formal 目录。浏览器实际仍失败，不能称供给性能已经完成验收，也不能把同 capture 的事后方向误差计算当原断言运行过。

本地浏览器采用项目 Playwright 1.57 配合临时 @sparticuz Chromium 143.0.7499.0；并非 CI 的 Chromium 143.0.7499.4。当前完整候选未重复跑 normal，复用总控持有的相同生产树结果。总控冻结 7b 的完整 P05 长流程不在本 worker 本轮执行范围。
